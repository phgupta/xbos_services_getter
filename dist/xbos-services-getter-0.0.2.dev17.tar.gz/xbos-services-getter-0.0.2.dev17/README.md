Getter for xbos services using Python 3.6

Documentation: https://xbos-services-getter.readthedocs.io/en/latest/
