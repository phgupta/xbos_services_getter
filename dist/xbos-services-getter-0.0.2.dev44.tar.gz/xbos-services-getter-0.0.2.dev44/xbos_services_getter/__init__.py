from xbos_services_getter.xbos_services_getter import *

